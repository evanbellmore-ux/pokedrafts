import { type MoveCounter, RandomTeams } from '../gen9/teams';
import { toID } from '../../../sim/dex';
import { type PRNG, type PRNGSeed } from '../../../sim/prng';

// Moves that restore HP:
const RECOVERY_MOVES = [
	'healorder', 'milkdrink', 'moonlight', 'morningsun', 'recover', 'roost', 'shoreup', 'slackoff', 'softboiled', 'strengthsap', 'synthesis',
];
// Moves that boost Attack:
const PHYSICAL_SETUP = [
	'bellydrum', 'bulkup', 'coil', 'curse', 'dragondance', 'fellstinger', 'honeclaws', 'howl', 'meditate', 'poweruppunch', 'swordsdance', 'tidyup', 'victorydance',
];
// Some moves that only boost Speed:
const SPEED_SETUP = [
	'agility', 'autotomize', 'flamecharge', 'raindance', 'rockpolish', 'snowscape', 'sunnyday', 'trailblaze',
];
// Conglomerate for ease of access
const SETUP = [
	'acidarmor', 'agility', 'autotomize', 'bellydrum', 'bulkup', 'calmmind', 'clangoroussoul', 'coil', 'cosmicpower', 'curse', 'dragondance',
	'fellstinger', 'flamecharge', 'growth', 'honeclaws', 'howl', 'irondefense', 'meditate', 'nastyplot', 'noretreat', 'poweruppunch', 'quiverdance',
	'raindance', 'rockpolish', 'shellsmash', 'shelter', 'shiftgear', 'sunnyday', 'swordsdance', 'tailglow', 'takeheart', 'tidyup', 'trailblaze', 'workup',
	'victorydance',
];
// Speed control moves (for doubles)
const SPEED_CONTROL = [
	'electroweb', 'glare', 'icywind', 'nuzzle', 'quash', 'tailwind', 'thunderwave', 'trickroom',
];
// Moves that shouldn't be the only STAB moves:
const NO_STAB = [
	'acidspray', 'accelerock', 'aquajet', 'bounce', 'breakingswipe', 'bulletpunch', 'chatter', 'chloroblast', 'clearsmog', 'covet',
	'dragontail', 'doomdesire', 'electroweb', 'eruption', 'explosion', 'fakeout', 'feint', 'fellstinger', 'flamecharge', 'flipturn', 'futuresight',
	'grassyglide', 'iceshard', 'icywind', 'incinerate', 'infestation', 'machpunch', 'meteorbeam', 'mortalspin', 'nuzzle', 'pluck', 'pursuit',
	'quickattack', 'rapidspin', 'reversal', 'selfdestruct', 'shadowsneak', 'skydrop', 'snarl', 'snaptrap', 'strugglebug', 'suckerpunch', 'trailblaze',
	'uturn', 'vacuumwave', 'voltswitch', 'watershuriken', 'waterspout',
];
// Hazard-setting moves
const HAZARDS = [
	'spikes', 'stealthrock', 'stickyweb', 'toxicspikes',
];
// Protect and its variants
const PROTECT_MOVES = [
	'banefulbunker', 'burningbulwark', 'detect', 'kingsshield', 'protect', 'silktrap', 'spikyshield',
];
// Moves that switch the user out
const PIVOT_MOVES = [
	'chillyreception', 'flipturn', 'partingshot', 'shedtail', 'teleport', 'uturn', 'voltswitch',
];

// Moves that should be paired together when possible
const MOVE_PAIRS = [
	['sleeptalk', 'rest'],
	['protect', 'wish'],
	['leechseed', 'substitute'],
	['reflect', 'lightscreen'],
];

/** Pokemon who always want priority STAB, and are fine with it as its only STAB move of that type */
const PRIORITY_POKEMON = [
	'golisopod', 'mimikyu', 'palafin', 'scizor', 'scizormega',
];

/** Pokemon who should never be in the lead slot. Currently just Kingambit, but more may be added in the future */
const NO_LEAD_POKEMON = [
	'kingambit',
];

const DOUBLES_NO_LEAD_POKEMON = [
	'basculegion', 'basculegionf', 'houndstone',
];

// 1.2x type boosting items
const TYPE_BOOSTING_ITEMS: { [k: string]: string } = {
	'Bug': 'Silver Powder',
	'Dark': 'Black Glasses',
	'Dragon': 'Dragon Fang',
	'Electric': 'Magnet',
	'Fairy': 'Fairy Feather',
	'Fighting': 'Black Belt',
	'Fire': 'Charcoal',
	'Flying': 'Sharp Beak',
	'Ghost': 'Spell Tag',
	'Grass': 'Miracle Seed',
	'Ground': 'Soft Sand',
	'Ice': 'Never-Melt Ice',
	'Normal': 'Silk Scarf',
	'Poison': 'Poison Barb',
	'Psychic': 'Twisted Spoon',
	'Rock': 'Hard Stone',
	'Steel': 'Metal Coat',
	'Water': 'Mystic Water',
};

export class RandomChampionsTeams extends RandomTeams {
	override randomSets: { [species: string]: RandomTeamsTypes.RandomSpeciesData } = require('./sets.json');
	override randomDoublesSets: { [species: string]: RandomTeamsTypes.RandomSpeciesData } = require('./doubles-sets.json');

	constructor(format: Format | string, prng: PRNG | PRNGSeed | null) {
		super(format, prng);

		this.noStab = NO_STAB;
		this.priorityPokemon = PRIORITY_POKEMON;

		this.moveEnforcementCheckers = {
			Bug: (movePool, moves, abilities, types, counter) => {
				if (['Fire', 'Steel'].some(m => types.has(m))) return false;
				return !counter.get('Bug');
			},
			Dark: (movePool, moves, abilities, types, counter) => !counter.get('Dark'),
			Dragon: (movePool, moves, abilities, types, counter) => !counter.get('Dragon'),
			Electric: (movePool, moves, abilities, types, counter) => !counter.get('Electric'),
			Fairy: (movePool, moves, abilities, types, counter) => !counter.get('Fairy'),
			Fighting: (movePool, moves, abilities, types, counter) => !counter.get('Fighting'),
			Fire: (movePool, moves, abilities, types, counter) => !counter.get('Fire'),
			Flying: (movePool, moves, abilities, types, counter, species) => !counter.get('Flying'),
			Ghost: (movePool, moves, abilities, types, counter) => !counter.get('Ghost'),
			Grass: (movePool, moves, abilities, types, counter, species) => (
				!counter.get('Grass') && (
					species.baseStats.atk >= 100 || movePool.includes('leafstorm') || types.has('Ghost')
				)
			),
			Ground: (movePool, moves, abilities, types, counter) => !counter.get('Ground'),
			Ice: (movePool, moves, abilities, types, counter) => !counter.get('Ice'),
			Normal: (movePool, moves, abilities, types, counter, species) => (
				!counter.get('Normal') && (
					movePool.includes('boomburst') || ['Electric', 'Fire', 'Ghost', 'Ground'].some(t => types.has(t)) ||
					species.baseSpecies === 'Squawkabilly'
				)
			),
			Poison: (movePool, moves, abilities, types, counter) => !counter.get('Poison'),
			Psychic: (movePool, moves, abilities, types, counter, species, teamDetails, isLead, isDoubles) => {
				if (['Dark', 'Ice'].some(m => types.has(m))) return false;
				if (['Water', 'Steel'].some(m => types.has(m)) && !isDoubles) return false;
				return !counter.get('Psychic');
			},
			Rock: (movePool, moves, abilities, types, counter, species) => (!counter.get('Rock') && species.baseStats.atk >= 80),
			Steel: (movePool, moves, abilities, types, counter, species) => (!counter.get('Steel') && species.baseStats.atk >= 60),
			Water: (movePool, moves, abilities, types, counter) => !counter.get('Water'),
		};
		this.cachedStatusMoves = this.dex.moves.all().filter(move => move.category === 'Status').map(move => move.id);
	}

	override cullMovePool(
		types: Set<string>,
		moves: Set<string>,
		abilities: string[],
		counter: MoveCounter,
		movePool: string[],
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
		isLead: boolean,
		preferredType: string,
		role: RandomTeamsTypes.Role,
		isDoubles: boolean,
	): void {
		if (moves.size + movePool.length <= this.maxMoveCount) return;
		// If we have two unfilled moves and only one unpaired move, cull the unpaired move.
		if (moves.size === this.maxMoveCount - 2) {
			const unpairedMoves = [...movePool];
			for (const pair of MOVE_PAIRS) {
				if (movePool.includes(pair[0]) && movePool.includes(pair[1])) {
					this.fastPop(unpairedMoves, unpairedMoves.indexOf(pair[0]));
					this.fastPop(unpairedMoves, unpairedMoves.indexOf(pair[1]));
				}
			}
			if (unpairedMoves.length === 1) {
				this.fastPop(movePool, movePool.indexOf(unpairedMoves[0]));
			}
		}

		// These moves are paired, and shouldn't appear if there is not room for them both.
		if (moves.size === this.maxMoveCount - 1) {
			for (const pair of MOVE_PAIRS) {
				if (movePool.includes(pair[0]) && movePool.includes(pair[1])) {
					this.fastPop(movePool, movePool.indexOf(pair[0]));
					this.fastPop(movePool, movePool.indexOf(pair[1]));
				}
			}
		}

		if (teamDetails.stickyWeb) {
			if (movePool.includes('stickyweb')) this.fastPop(movePool, movePool.indexOf('stickyweb'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}
		if (teamDetails.stealthRock) {
			if (movePool.includes('stealthrock')) this.fastPop(movePool, movePool.indexOf('stealthrock'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}
		if (teamDetails.defog || teamDetails.rapidSpin) {
			if (movePool.includes('defog')) this.fastPop(movePool, movePool.indexOf('defog'));
			if (movePool.includes('rapidspin')) this.fastPop(movePool, movePool.indexOf('rapidspin'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}
		if (teamDetails.toxicSpikes) {
			if (movePool.includes('toxicspikes')) this.fastPop(movePool, movePool.indexOf('toxicspikes'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}
		if (teamDetails.spikes && teamDetails.spikes >= 2) {
			if (movePool.includes('spikes')) this.fastPop(movePool, movePool.indexOf('spikes'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}
		if (teamDetails.statusCure) {
			if (movePool.includes('healbell')) this.fastPop(movePool, movePool.indexOf('healbell'));
			if (moves.size + movePool.length <= this.maxMoveCount) return;
		}

		const statusMoves = this.cachedStatusMoves;
		const statusInflictingMoves = ["nuzzle", 'thunderwave', 'toxic', 'willowisp', 'yawn'];

		if (isDoubles) {
			const doublesIncompatiblePairs = [
				// In order of decreasing generalizability
				[SPEED_CONTROL, SPEED_CONTROL],
				[SETUP, ['fakeout', 'helpinghand']],
				[RECOVERY_MOVES, ['healpulse', 'lifedew']],
				['healpulse', 'lifedew'],
				['coaching', 'helpinghand'],
			];

			for (const pair of doublesIncompatiblePairs) this.incompatibleMoves(moves, movePool, pair[0], pair[1]);

			if (!role.includes('Protect')) this.incompatibleMoves(moves, movePool, PROTECT_MOVES, 'uturn');
		}

		// General incompatibilities
		const incompatiblePairs = [
			// These moves don't mesh well with other aspects of the set
			[statusMoves, ['healingwish', 'switcheroo', 'trick']],
			[SETUP, PIVOT_MOVES],
			[SETUP, HAZARDS],
			[SETUP, ['defog', 'haze', 'toxic']],
			[PHYSICAL_SETUP, PHYSICAL_SETUP],
			[SPEED_SETUP, 'quickattack'],
			['curse', 'rapidspin'],
			['defog', HAZARDS],
			['uturn', 'trick'],
			['substitute', PIVOT_MOVES],

			// These attacks are redundant with each other
			[['psychic', 'psychicnoise'], ['psyshock', 'psychicnoise']],
			[['muddywater', 'scald', 'surf', 'waterfall'], 'hydropump'],
			[['gigadrain', 'hornleech', 'tropkick'], ['leafstorm', 'powerwhip', 'woodhammer']],
			['dazzlinggleam', ['alluringvoice', 'moonblast', 'playrough']],
			[['fireblast', 'flamethrower'], ['fierydance', 'heatwave', 'overheat']],
			['aurasphere', 'focusblast'],
			['closecombat', 'drainpunch'],
			[['dragonpulse', 'ficklebeam'], 'dracometeor'],
			['risingvoltage', 'volttackle'],
			['rockslide', 'stoneedge'],
			['foulplay', 'knockoff'],

			// Status move incompatibilities
			[['taunt', 'clearsmog'], 'encore'],
			['roar', 'yawn'],
			[statusInflictingMoves, 'toxicspikes'],
			[statusInflictingMoves, statusInflictingMoves],
		];

		for (const pair of incompatiblePairs) this.incompatibleMoves(moves, movePool, pair[0], pair[1]);

		if (!types.has('Dark') && preferredType !== 'Dark') {
			this.incompatibleMoves(moves, movePool, 'knockoff', 'suckerpunch');
		}

		if (!types.has('Ice') && preferredType !== 'Ice') {
			this.incompatibleMoves(moves, movePool, 'icebeam', 'icywind');
		}

		// This space reserved for assorted hardcodes that make little sense out of context and can't fit in the const:
		if (!isDoubles) {
			// To force Stealth Rock on Camerupt
			if (species.id === 'cameruptmega') this.incompatibleMoves(moves, movePool, 'ancientpower', 'willowisp');
			// To force Grassy Glide on Rillaboom
			if (species.id === 'rillaboom') this.incompatibleMoves(moves, movePool, 'highhorsepower', 'knockoff');
		}
	}

	// Generate random moveset for a given species, role, preferred type.
	override randomMoveset(
		types: Set<string>,
		abilities: string[],
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
		isLead: boolean,
		movePool: string[],
		preferredType: string,
		role: RandomTeamsTypes.Role,
		isDoubles: boolean,
	): Set<string> {
		const moves = new Set<string>();
		let counter = this.queryMoves(moves, species, preferredType, abilities);
		this.cullMovePool(types, moves, abilities, counter, movePool, teamDetails, species, isLead,
			preferredType, role, isDoubles);

		// If there are only four moves, add all moves and return early
		if (movePool.length <= this.maxMoveCount) {
			while (movePool.length) {
				const moveid = this.sample(movePool);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
			return moves;
		}

		const runEnforcementChecker = (checkerName: string) => {
			if (!this.moveEnforcementCheckers[checkerName]) return false;
			return this.moveEnforcementCheckers[checkerName](
				movePool, moves, abilities, types, counter, species, teamDetails, isLead, isDoubles, preferredType, role
			);
		};

		// Add required move (e.g. Relic Song for Meloetta-P)
		if (species.requiredMove) {
			const move = this.dex.moves.get(species.requiredMove).id;
			counter = this.addMove(move, moves, types, abilities, teamDetails, species, isLead,
				movePool, preferredType, role, isDoubles);
		}

		// Add other moves you really want to have, e.g. STAB, recovery, setup.

		// Enforce Aurora Veil, Blizzard, Court Change, Revival Blessing, and Sticky Web
		for (const moveid of ['auroraveil', 'blizzard', 'courtchange', 'revivalblessing', 'stickyweb']) {
			if (movePool.includes(moveid)) {
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce hazard removal on Bulky Support if the team doesn't already have it
		if (role === 'Bulky Support' && !teamDetails.defog && !teamDetails.rapidSpin) {
			if (movePool.includes('rapidspin')) {
				counter = this.addMove('rapidspin', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
			if (movePool.includes('defog')) {
				counter = this.addMove('defog', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Knock Off on pure Normal- and Fighting-types
		if (types.size === 1 && (types.has('Normal') || types.has('Fighting'))) {
			if (movePool.includes('knockoff')) {
				counter = this.addMove('knockoff', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Body Press on sets with Iron Defense
		if (movePool.includes('irondefense') || movePool.includes('shelter')) {
			if (movePool.includes('bodypress')) {
				counter = this.addMove('bodypress', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Stealth Rock on sets with phazing moves
		if (['dragontail', 'roar', 'whirlwind'].some(m => movePool.includes(m))) {
			if (movePool.includes('stealthrock') && !teamDetails.stealthRock) {
				counter = this.addMove('stealthrock', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Protect on Sharpedo and Sharpedo-Mega
		if (species.baseSpecies === 'Sharpedo') {
			if (movePool.includes('protect')) {
				counter = this.addMove('protect', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce King's Shield on Bulky Attacker Aegislash
		if (species.id === 'aegislash' && role === 'Bulky Attacker') {
			if (movePool.includes('kingsshield')) {
				counter = this.addMove('kingsshield', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Flip Turn on Qwilfish, in both singles and doubles
		if (species.id === 'qwilfish') {
			if (movePool.includes('flipturn')) {
				counter = this.addMove('flipturn', moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce STAB priority
		if (['Wallbreaker', 'Doubles Wallbreaker'].includes(role) || this.priorityPokemon.includes(species.id)) {
			const priorityMoves = [];
			for (const moveid of movePool) {
				const move = this.dex.moves.get(moveid);
				const moveType = this.getMoveType(move, species, abilities, preferredType);
				if (types.has(moveType) && move.priority > 0 && (move.basePower || move.basePowerCallback)) {
					priorityMoves.push(moveid);
				}
			}
			if (priorityMoves.length) {
				const moveid = this.sample(priorityMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce STAB
		for (const type of types) {
			// Check if a STAB move of that type should be required
			const stabMoves = [];
			for (const moveid of movePool) {
				const move = this.dex.moves.get(moveid);
				const moveType = this.getMoveType(move, species, abilities, preferredType);
				if (!this.noStab.includes(moveid) && (move.basePower || move.basePowerCallback) && type === moveType) {
					stabMoves.push(moveid);
				}
			}
			while (runEnforcementChecker(type)) {
				if (!stabMoves.length) break;
				const moveid = this.sampleNoReplace(stabMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce Preferred Type
		if (!counter.get(preferredType)) {
			const stabMoves = [];
			for (const moveid of movePool) {
				const move = this.dex.moves.get(moveid);
				const moveType = this.getMoveType(move, species, abilities, preferredType);
				if (!this.noStab.includes(moveid) && (move.basePower || move.basePowerCallback) && preferredType === moveType) {
					stabMoves.push(moveid);
				}
			}
			if (stabMoves.length) {
				const moveid = this.sample(stabMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// If no STAB move was added, add a STAB move
		if (!counter.get('stab')) {
			const stabMoves = [];
			for (const moveid of movePool) {
				const move = this.dex.moves.get(moveid);
				const moveType = this.getMoveType(move, species, abilities, preferredType);
				if (!this.noStab.includes(moveid) && (move.basePower || move.basePowerCallback) && types.has(moveType)) {
					stabMoves.push(moveid);
				}
			}
			if (stabMoves.length) {
				const moveid = this.sample(stabMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce recovery
		if (['Bulky Support', 'Bulky Attacker', 'Bulky Setup'].includes(role)) {
			const recoveryMoves = movePool.filter(moveid => RECOVERY_MOVES.includes(moveid));
			if (recoveryMoves.length) {
				const moveid = this.sample(recoveryMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce setup
		if (role.includes('Setup')) {
			// First, try to add a non-Speed setup move
			const nonSpeedSetupMoves = movePool.filter(moveid => SETUP.includes(moveid) && !SPEED_SETUP.includes(moveid));
			if (nonSpeedSetupMoves.length) {
				const moveid = this.sample(nonSpeedSetupMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			} else {
				// No non-Speed setup moves, so add any (Speed) setup move
				const setupMoves = movePool.filter(moveid => SETUP.includes(moveid));
				if (setupMoves.length) {
					const moveid = this.sample(setupMoves);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}
		}

		// Enforce moves in doubles
		if (isDoubles) {
			// Enforce Final Gambit, Mortal Spin, Shed Tail, and redirecting moves on everything
			for (const moveid of ['finalgambit', 'mortalspin', 'shedtail', 'followme', 'ragepowder']) {
				if (movePool.includes(moveid)) {
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}

			// Enforce Protect on Protect roles
			if (role.includes('Protect')) {
				const protectMoves = movePool.filter(moveid => PROTECT_MOVES.includes(moveid));
				if (protectMoves.length) {
					const moveid = this.sample(protectMoves);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}

			// Enforce Fake Out on Doubles Support
			if (role === 'Doubles Support') {
				if (movePool.includes('fakeout')) {
					counter = this.addMove('fakeout', moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}

			// Enforce Trick Room on Doubles Wallbreaker and slow mons
			if (role === 'Doubles Wallbreaker' || species.baseStats.spe <= 50) {
				if (movePool.includes('trickroom')) {
					counter = this.addMove('trickroom', moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}

			// Enforce speed control on Doubles Fast Attacker and Doubles Support
			if (['Doubles Fast Attacker', 'Doubles Support'].includes(role)) {
				const speedControl = movePool.filter(moveid => SPEED_CONTROL.includes(moveid));
				if (speedControl.length) {
					const moveid = this.sample(speedControl);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}

			// Enforce Fake Out or Protect on Doubles Fast Attacker, prioritising Fake Out
			if (role === 'Doubles Fast Attacker') {
				if (movePool.includes('fakeout')) {
					counter = this.addMove('fakeout', moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				} else {
					const protectMoves = movePool.filter(moveid => PROTECT_MOVES.includes(moveid));
					if (protectMoves.length) {
						const moveid = this.sample(protectMoves);
						counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
							movePool, preferredType, role, isDoubles);
					}
				}
			}

			// Enforce recovery moves and Protect on Doubles Bulky Setup if it doesn't have a setup move
			if (role === 'Doubles Bulky Setup' && !counter.get('setup')) {
				const recoveryMoves = movePool.filter(moveid => RECOVERY_MOVES.includes(moveid));
				if (recoveryMoves.length) {
					const moveid = this.sample(recoveryMoves);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}

				const protectMoves = movePool.filter(moveid => PROTECT_MOVES.includes(moveid));
				if (protectMoves.length) {
					const moveid = this.sample(protectMoves);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}
		}

		// Enforce a move not on the noSTAB list
		if (!counter.damagingMoves.size) {
			// Choose an attacking move
			const attackingMoves = [];
			for (const moveid of movePool) {
				const move = this.dex.moves.get(moveid);
				if (!this.noStab.includes(moveid) && (move.category !== 'Status')) attackingMoves.push(moveid);
			}
			if (attackingMoves.length) {
				const moveid = this.sample(attackingMoves);
				counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
					movePool, preferredType, role, isDoubles);
			}
		}

		// Enforce coverage move
		if (!['Fast Support', 'Bulky Support', 'Bulky Setup', 'Doubles Bulky Setup', 'Doubles Support'].includes(role)) {
			if (counter.damagingMoves.size === 1) {
				// Find the type of the current attacking move
				const currentAttackType = counter.damagingMoves.values().next().value!.type;
				// Choose an attacking move that is of different type to the current single attack
				const coverageMoves = [];
				for (const moveid of movePool) {
					const move = this.dex.moves.get(moveid);
					const moveType = this.getMoveType(move, species, abilities, preferredType);
					if (!this.noStab.includes(moveid) && (move.basePower || move.basePowerCallback)) {
						if (currentAttackType !== moveType) coverageMoves.push(moveid);
					}
				}
				if (coverageMoves.length) {
					const moveid = this.sample(coverageMoves);
					counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}
		}

		// Choose remaining moves randomly from movepool and add them to moves list:
		while (moves.size < this.maxMoveCount && movePool.length) {
			const moveid = this.sample(movePool);
			counter = this.addMove(moveid, moves, types, abilities, teamDetails, species, isLead,
				movePool, preferredType, role, isDoubles);
			for (const pair of MOVE_PAIRS) {
				if (moveid === pair[0] && movePool.includes(pair[1])) {
					counter = this.addMove(pair[1], moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
				if (moveid === pair[1] && movePool.includes(pair[0])) {
					counter = this.addMove(pair[0], moves, types, abilities, teamDetails, species, isLead,
						movePool, preferredType, role, isDoubles);
				}
			}
		}
		return moves;
	}

	override shouldCullAbility(
		ability: string,
		types: Set<string>,
		moves: Set<string>,
		abilities: string[],
		counter: MoveCounter,
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
	): boolean {
		switch (ability) {
		case 'Chlorophyll': case 'Solar Power':
			return !teamDetails.sun;
		case 'Hydration': case 'Swift Swim':
			return !teamDetails.rain;
		case 'Overgrow':
			return !counter.get('Grass');
		case 'Sand Force': case 'Sand Rush':
			return !teamDetails.sand;
		case 'Slush Rush':
			return !teamDetails.snow;
		case 'Sheer Force': case 'Skill Link':
			return !counter.get(toID(ability));
		}

		return false;
	}

	override getAbility(
		types: Set<string>,
		moves: Set<string>,
		abilities: string[],
		counter: MoveCounter,
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
	): string {
		if (abilities.length <= 1) return abilities[0];

		// Hard-code abilities here
		if (species.id === 'toucannon') {
			if (counter.get('skilllink')) return 'Skill Link';
			if (counter.get('sheerforce')) return 'Sheer Force';
		}
		if (abilities.includes('Slush Rush') && moves.has('snowscape')) return 'Slush Rush';

		const abilityAllowed: string[] = [];
		// Obtain a list of abilities that are allowed (not culled)
		for (const ability of abilities) {
			if (!this.shouldCullAbility(ability, types, moves, abilities, counter, teamDetails, species)) {
				abilityAllowed.push(ability);
			}
		}

		// Pick a random allowed ability
		if (abilityAllowed.length >= 1) return this.sample(abilityAllowed);

		// If all abilities are rejected, prioritize weather abilities over non-weather abilities
		if (!abilityAllowed.length) {
			const weatherAbilities = abilities.filter(
				a => ['Chlorophyll', 'Sand Rush', 'Slush Rush', 'Solar Power', 'Swift Swim'].includes(a)
			);
			if (weatherAbilities.length) return this.sample(weatherAbilities);
		}

		// Pick a random allowed ability
		if (abilityAllowed.length >= 1) return this.sample(abilityAllowed);

		// Pick a random ability
		return this.sample(abilities);
	}

	override getPriorityItem(
		ability: string,
		types: Set<string>,
		moves: Set<string>,
		counter: MoveCounter,
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
		isLead: boolean,
		preferredType: string,
		role: RandomTeamsTypes.Role,
		isDoubles: boolean,
	): string | undefined {
		if (species.requiredItems) return this.sample(species.requiredItems);
		if (species.id === 'pikachu') return 'Light Ball';
		if (['farfetchd', 'sirfetchd'].includes(species.id)) return 'Leek';
		// Move this back to getDoublesItem() if Choice Band/Specs get added
		if (role === 'Choice Item user') return 'Choice Scarf';
		if (
			['Cheek Pouch', 'Cud Chew', 'Emergency Exit', 'Harvest', 'Ripen'].some(m => ability === m) || moves.has('bellydrum')
		) return 'Sitrus Berry';
		if (species.id === 'alakazam' && this.randomChance(1, 2)) return 'Focus Sash';
		if (species.id === 'glimmora') return 'Focus Sash';
		if (species.id === 'rampardos' && role === 'Fast Attacker') return 'Choice Scarf';
		if (species.id === 'ditto' && !isDoubles) return 'Choice Scarf';
		if (species.id === 'inteleon' && moves.has('focusenergy')) return 'Scope Lens';
		if (['healingwish', 'switcheroo', 'trick'].some(m => moves.has(m))) return 'Choice Scarf';
		if (ability === 'Unburden') return (moves.has('closecombat') || moves.has('leafstorm')) ? 'White Herb' : 'Sitrus Berry';
		if (moves.has('shellsmash')) return 'White Herb';
		if ((ability === 'Magic Guard' || ability === 'Sheer Force') && species.id !== 'toucannon') return 'Life Orb';
		if (moves.has('acrobatics')) return '';
		if (moves.has('auroraveil') || moves.has('lightscreen') && moves.has('reflect')) return 'Light Clay';
		if (
			moves.has('rest') && !moves.has('sleeptalk') &&
			ability !== 'Natural Cure' && ability !== 'Shed Skin'
		) return 'Chesto Berry';
		if (types.has('Normal') && moves.has('doubleedge') && moves.has('fakeout')) return 'Silk Scarf';
		if (
			(species.id === 'froslass' && moves.has('tripleaxel')) || moves.has('populationbomb') ||
			(ability === 'Hustle' && this.randomChance(1, 2)) ||
			(species.id === 'tsareena' && role === 'Offensive Protect')
		) return 'Wide Lens';
		// 1.2x type boosting items
		if (types.has(preferredType)) return TYPE_BOOSTING_ITEMS[preferredType];
	}

	override getDoublesItem(
		ability: string,
		types: Set<string>,
		moves: Set<string>,
		counter: MoveCounter,
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
		isLead: boolean,
		preferredType: string,
		role: RandomTeamsTypes.Role,
	): string {
		if (role === 'Doubles Fast Attacker') return 'Focus Sash';
		if (role === 'Doubles Bulky Setup' && !moves.has('dragondance')) return 'Leftovers';
		if (['Offensive Protect', 'Doubles Wallbreaker', 'Doubles Setup Sweeper'].includes(role)) return 'Life Orb';
		return 'Sitrus Berry';
	}

	override getItem(
		ability: string,
		types: Set<string>,
		moves: Set<string>,
		counter: MoveCounter,
		teamDetails: RandomTeamsTypes.TeamDetails,
		species: Species,
		isLead: boolean,
		preferredType: string,
		role: RandomTeamsTypes.Role,
	): string {
		// const defensiveStatTotal = species.baseStats.hp + species.baseStats.def + species.baseStats.spd;
		if (
			role === 'Fast Attacker' && !counter.get('priority') &&
			['fakeout', 'trailblaze'].every(m => !moves.has(m)) &&
			(!counter.get('Status') || counter.get('Status') === 1 && moves.has('partingshot'))
		) return 'Choice Scarf';

		if (['flamecharge', 'kingsshield', 'nuzzle', 'substitute'].some(m => moves.has(m))) return 'Leftovers';
		if (moves.has('outrage') && counter.get('setup')) return 'Lum Berry';

		// Give physically bulky Pokemon with either Regenerator or a recovery move a chance at Rocky Helmet
		if (
			ability === 'Rough Skin' || (
				ability === 'Regenerator' && (role === 'Bulky Support' || role === 'Bulky Attacker') &&
				(species.baseStats.hp + species.baseStats.def) >= 180 && this.randomChance(1, 2)
			) || (
				ability !== 'Regenerator' && !counter.get('setup') && counter.get('recovery') &&
				(species.baseStats.hp + species.baseStats.def) > 200 && this.randomChance(1, 2)
			)
		) return 'Rocky Helmet';

		// Default to Leftovers for Bulky roles
		if (role.includes('Bulky')) return 'Leftovers';

		// Default to Life Orb for offensive roles
		if (
			['Fast Attacker', 'Setup Sweeper', 'Wallbreaker'].includes(role) && this.dex.getEffectiveness('Rock', species) < 2
		) return 'Life Orb';

		// Fast Support defaults to Life Orb if >= 3 attacks and Leftovers otherwise. It can generate Focus Sash in the lead slot with hazards
		if (role === 'Fast Support') {
			if (isLead && !counter.get('recovery') && !counter.get('recoil') && counter.get('hazards')) return 'Focus Sash';
			return (
				counter.get('Physical') + counter.get('Special') >= 3 && this.dex.getEffectiveness('Rock', species) < 2
			) ? 'Life Orb' : 'Leftovers';
		}

		// Default to Leftovers
		return 'Leftovers';
	}

	override randomSet(
		species: string | Species,
		teamDetails: RandomTeamsTypes.TeamDetails = {},
		isLead = false,
		isDoubles = false
	): RandomTeamsTypes.RandomSet {
		const ruleTable = this.dex.formats.getRuleTable(this.format);

		species = this.dex.species.get(species);
		const forme = this.getForme(species);
		const sets = this[`random${isDoubles ? 'Doubles' : ''}Sets`][species.id]["sets"];
		const possibleSets = [];

		for (const set of sets) possibleSets.push(set);

		const set = this.sampleIfArray(possibleSets);
		const role = set.role;
		const movePool: string[] = [];
		for (const movename of set.movepool) {
			movePool.push(this.dex.moves.get(movename).id);
		}
		const preferredTypes = set.preferredTypes;
		const preferredType = this.sampleIfArray(preferredTypes) || '';

		let ability = '';
		let item = undefined;

		const evs = { hp: 11, atk: 11, def: 11, spa: 11, spd: 11, spe: 11 };
		const ivs = { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 };

		const types = new Set(species.types);
		const baseAbilities = set.abilities!;
		// Use the mega's ability for moveset generation
		const abilities = (species.battleOnly && !species.requiredAbility) ? Object.values(species.abilities) : baseAbilities;

		// Get moves
		const moves = this.randomMoveset(types, abilities, teamDetails, species, isLead, movePool,
			preferredType, role, isDoubles);
		const counter = this.queryMoves(moves, species, preferredType, abilities);

		// Get ability
		ability = this.getAbility(types, moves, baseAbilities, counter, teamDetails, species);

		// Get items
		item = this.getPriorityItem(
			ability, types, moves, counter, teamDetails, species, isLead, preferredType, role, isDoubles
		);
		if (item === undefined) {
			if (isDoubles) {
				item = this.getDoublesItem(ability, types, moves, counter, teamDetails, species, isLead, preferredType, role);
			} else {
				item = this.getItem(ability, types, moves, counter, teamDetails, species, isLead, preferredType, role);
			}
		}

		// Get level
		const level = this.getLevel(species, isDoubles);

		// Minimize confusion damage
		const noAttackStatMoves = [...moves].every(m => {
			const move = this.dex.moves.get(m);
			if (move.damageCallback || move.damage) return true;
			if (move.id === 'shellsidearm') return false;
			return move.category !== 'Physical' || move.id === 'bodypress' || move.id === 'foulplay';
		});
		if (
			noAttackStatMoves && !moves.has('transform') && this.format.mod !== 'partnersincrime' &&
			!ruleTable.has('forceofthefallenmod')
		) {
			evs.atk = 0;
		}

		// Prepare optimal HP
		const srImmunity = ability === 'Magic Guard';
		let srWeakness = srImmunity ? 0 : this.dex.getEffectiveness('Rock', species);
		// Crash damage move users want an odd HP to survive two misses
		if (['axekick', 'highjumpkick', 'jumpkick', 'supercellslam'].some(m => moves.has(m))) srWeakness = 2;
		// Treat Charizard-Mega-X like Charizard-Mega-Y for bluffing purposes
		if (species.id === 'charizardmegax') srWeakness = 2;
		while (evs.hp > 0) {
			const hp = Math.floor((2 * species.baseStats.hp + ivs.hp + Math.max(2 * evs.hp - 1, 0) + 100) * level / 100) + 10;
			if (moves.has('substitute') && item !== 'Leftovers') {
				if (item === 'Sitrus Berry' || item === 'Salac Berry') {
					// Two Substitutes should activate Sitrus Berry or Power Construct
					if (hp % 4 === 0) break;
				} else {
					// Should be able to use Substitute four times from full HP without fainting
					if (hp % 4 > 0) break;
				}
			} else if ((moves.has('bellydrum') || moves.has('shedtail')) && item === 'Sitrus Berry') {
				// Belly Drum should activate Sitrus Berry
				if (hp % 2 === 0) break;
			} else {
				if (srWeakness <= 0 || ability === 'Regenerator') break;
				// Ignore 2x weaknesses if it's holding Leftovers or a doubles format.
				if (srWeakness === 1 && (item === 'Leftovers' || isDoubles)) break;

				// Maximise number of Stealth Rock switch-ins without fainting
				if (item !== 'Sitrus Berry' && hp % (4 / srWeakness) > 0) break;
				// Minimise number of Stealth Rock switch-ins to activate Sitrus Berry
				if (item === 'Sitrus Berry' && hp % (4 / srWeakness) === 0) break;
			}
			evs.hp--;
		}

		if (['gyroball', 'metalburst', 'trickroom'].some(m => moves.has(m))) evs.spe = 0;

		// shuffle moves to add more randomness to camomons
		const shuffledMoves = Array.from(moves);
		this.prng.shuffle(shuffledMoves);

		return {
			name: species.baseSpecies,
			species: forme,
			speciesId: species.id,
			gender: species.gender || (this.random(2) ? 'F' : 'M'),
			shiny: this.randomChance(1, 1024),
			level,
			moves: shuffledMoves,
			ability,
			evs,
			ivs,
			item,
			role,
		};
	}

	/**
	 * Checks if the new species is compatible with the other mons currently on the team.
	 */
	override getPokemonCompatibility(
		species: Species,
		pokemon: RandomTeamsTypes.RandomSet[],
		isDoubles = false
	): boolean {
		const webSetters = ['ariados', 'slurpuff', 'araquanid'];
		const screenSetters = [
			'ninetalesalola', 'abomasnow', 'abomasnowmega', 'froslassmega', 'vanilluxe', 'aurorus', 'grimmsnarl', 'meowstic',
		];

		const doublesScreenSetters = [...screenSetters, 'klefki'];

		const sunSetters = ['charizardmegay', 'ninetales', 'torkoal'];
		const rainSetters = ['politoed', 'pelipper'];
		const sandSetters = ['tyranitar', 'tyranitarmega', 'hippowdon'];
		const snowSetters = ['ninetalesalola', 'abomasnow', 'abomasnowmega', 'froslassmega', 'vanilluxe', 'aurorus'];

		const incompatiblePokemon = [
			// These combinations are prevented to avoid double webs or screens.
			[webSetters, webSetters],
			[screenSetters, screenSetters],

			// These Pokemon are incompatible because the presence of one actively harms the other.
			// Screen Cleaner is a bad ability
			['mrrime', screenSetters],
			// Prevent Dry Skin + sun setting ability
			[['toxicroak', 'heliolisk'], sunSetters],
		];

		const doublesIncompatiblePokemon = [
			// Lightning Rod Electrics
			[['pikachu', 'raichu', 'manectric'], ['pikachu', 'raichu', 'manectric']],

			// These combinations are prevented to avoid double webs or screens.
			[webSetters, webSetters],
			[doublesScreenSetters, doublesScreenSetters],

			// These Pokemon are incompatible because the presence of one actively harms the other.
			// Screen Cleaner is a bad ability
			['mrrime', doublesScreenSetters],
			// Prevent Dry Skin + sun setting ability
			[['toxicroak', 'heliolisk'], sunSetters],

			// Prevent conflicting weather abilities from generating together
			[sunSetters, [...rainSetters, ...sandSetters, ...snowSetters]],
			[rainSetters, [...sandSetters, ...snowSetters]],
			[sandSetters, snowSetters],
		];

		const incompatibilityList = isDoubles ? doublesIncompatiblePokemon : incompatiblePokemon;

		for (const pair of incompatibilityList) {
			const monsArrayA = (Array.isArray(pair[0])) ? pair[0] : [pair[0]];
			const monsArrayB = (Array.isArray(pair[1])) ? pair[1] : [pair[1]];
			if (monsArrayB.includes(species.id)) {
				if (pokemon.some(m => monsArrayA.includes(m.speciesId!))) return false;
			}
			if (monsArrayA.includes(species.id)) {
				if (pokemon.some(m => monsArrayB.includes(m.speciesId!))) return false;
			}
		}

		return true;
	}

	override randomTeam() {
		this.enforceNoDirectCustomBanlistChanges();

		const seed = this.prng.getSeed();
		const ruleTable = this.dex.formats.getRuleTable(this.format);
		const pokemon: RandomTeamsTypes.RandomSet[] = [];

		// For Monotype
		const isMonotype = !!this.forceMonotype || ruleTable.has('sametypeclause');
		const isDoubles = this.format.gameType !== 'singles';
		const typePool = this.dex.types.names().filter(name => name !== "Stellar");
		const type = this.forceMonotype || this.sample(typePool);

		const baseFormes: { [k: string]: number } = {};
		let hasMega = false;

		const typeCount: { [k: string]: number } = {};
		const typeComboCount: { [k: string]: number } = {};
		const typeWeaknesses: { [k: string]: number } = {};
		const typeDoubleWeaknesses: { [k: string]: number } = {};
		const teamDetails: RandomTeamsTypes.TeamDetails = {};

		const pokemonList = isDoubles ? Object.keys(this.randomDoublesSets) : Object.keys(this.randomSets);
		const [pokemonPool, baseSpeciesPool] = this.getPokemonPool(type, pokemon, isMonotype, pokemonList);
		while (baseSpeciesPool.length && pokemon.length < this.maxTeamSize) {
			const baseSpecies = this.sampleNoReplace(baseSpeciesPool);
			const currentSpeciesPool: Species[] = [];
			// Check if the base species has a mega forme available
			let canMega = false;
			for (const poke of pokemonPool[baseSpecies]) {
				const species = this.dex.species.get(poke);
				if (!hasMega && species.isMega) canMega = true;
			}
			for (const poke of pokemonPool[baseSpecies]) {
				const species = this.dex.species.get(poke);
				// Prevent multiple megas
				if (hasMega && species.isMega) continue;
				// Prevent base forme, if a mega is available
				if (canMega && !species.isMega) continue;
				currentSpeciesPool.push(species);
			}
			const species = this.sample(currentSpeciesPool);

			if (!species.exists) continue;

			// Limit to one of each species (Species Clause)
			if (baseFormes[species.baseSpecies]) continue;

			// Illusion shouldn't be on the last slot
			if (species.baseSpecies === 'Zoroark' && pokemon.length < 1) continue;

			const types = species.types;
			const typeCombo = types.slice().sort().join();
			const weakToFreezeDry = (
				this.dex.getEffectiveness('Ice', species) > 0 ||
				(this.dex.getEffectiveness('Ice', species) > -2 && types.includes('Water'))
			);
			// Dynamically scale limits for different team sizes. The default and minimum value is 1.
			const limitFactor = Math.round(this.maxTeamSize / 6) || 1;

			if (!isMonotype && !this.forceMonotype) {
				let skip = false;

				// Limit two of any type
				for (const typeName of types) {
					if (typeCount[typeName] >= 2 * limitFactor) {
						skip = true;
						break;
					}
				}
				if (skip) continue;

				// Limit three weak to any type, and one double weak to any type
				for (const typeName of this.dex.types.names()) {
					// it's weak to the type
					if (this.dex.getEffectiveness(typeName, species) > 0) {
						if (!typeWeaknesses[typeName]) typeWeaknesses[typeName] = 0;
						if (typeWeaknesses[typeName] >= 3 * limitFactor) {
							skip = true;
							break;
						}
					}
					if (this.dex.getEffectiveness(typeName, species) > 1) {
						if (!typeDoubleWeaknesses[typeName]) typeDoubleWeaknesses[typeName] = 0;
						if (typeDoubleWeaknesses[typeName] >= limitFactor) {
							skip = true;
							break;
						}
					}
				}
				if (skip) continue;

				// Count Dry Skin/Fluffy as Fire weaknesses
				if (
					this.dex.getEffectiveness('Fire', species) === 0 &&
					Object.values(species.abilities).filter(a => ['Dry Skin', 'Fluffy'].includes(a)).length
				) {
					if (!typeWeaknesses['Fire']) typeWeaknesses['Fire'] = 0;
					if (typeWeaknesses['Fire'] >= 3 * limitFactor) continue;
				}

				// Limit four weak to Freeze-Dry
				if (weakToFreezeDry) {
					if (!typeWeaknesses['Freeze-Dry']) typeWeaknesses['Freeze-Dry'] = 0;
					if (typeWeaknesses['Freeze-Dry'] >= 4 * limitFactor) continue;
				}

				// Check compatibility with team
				if (!this.getPokemonCompatibility(species, pokemon, isDoubles)) continue;
			}

			// Limit three of any type combination in Monotype
			if (!this.forceMonotype && isMonotype && (typeComboCount[typeCombo] >= 3 * limitFactor)) continue;

			const isLead = (
				(pokemon.length === this.maxTeamSize - 1 || isDoubles && pokemon.length === this.maxTeamSize - 2) &&
				!ruleTable.has('pickedteamsize') && !ruleTable.has('teampreview')
			);
			const set = this.randomSet(species, teamDetails, isLead, isDoubles);
			// Some Pokemon should not be in the lead slot
			if (
				(isDoubles && DOUBLES_NO_LEAD_POKEMON.includes(species.id) && isLead) ||
				(!isDoubles && NO_LEAD_POKEMON.includes(species.id) && isLead)
			) {
				pokemon.push(set);
			} else {
				pokemon.unshift(set);
			}

			// Don't bother tracking details for the last Pokemon
			if (pokemon.length === this.maxTeamSize) break;

			// Now that our Pokemon has passed all checks, we can increment our counters
			baseFormes[species.baseSpecies] = 1;

			// Increment type counters
			for (const typeName of types) {
				if (typeName in typeCount) {
					typeCount[typeName]++;
				} else {
					typeCount[typeName] = 1;
				}
			}
			if (typeCombo in typeComboCount) {
				typeComboCount[typeCombo]++;
			} else {
				typeComboCount[typeCombo] = 1;
			}

			// Increment weakness counter
			for (const typeName of this.dex.types.names()) {
				// it's weak to the type
				if (this.dex.getEffectiveness(typeName, species) > 0) {
					typeWeaknesses[typeName]++;
				}
				if (this.dex.getEffectiveness(typeName, species) > 1) {
					typeDoubleWeaknesses[typeName]++;
				}
			}
			// Count Dry Skin/Fluffy as Fire weaknesses
			if (['Dry Skin', 'Fluffy'].includes(set.ability) && this.dex.getEffectiveness('Fire', species) === 0) {
				typeWeaknesses['Fire']++;
			}
			if (weakToFreezeDry) typeWeaknesses['Freeze-Dry']++;

			// Track what the team has
			if (this.dex.items.get(set.item).megaStone) hasMega = true;
			if (set.ability === 'Drizzle' || set.moves.includes('raindance')) teamDetails.rain = 1;
			if (set.ability === 'Drought' || set.moves.includes('sunnyday')) teamDetails.sun = 1;
			if (set.ability === 'Sand Stream') teamDetails.sand = 1;
			if (set.ability === 'Snow Warning' || set.moves.includes('snowscape') || set.moves.includes('chillyreception')) {
				teamDetails.snow = 1;
			}
			if (set.moves.includes('healbell')) teamDetails.statusCure = 1;
			if (set.moves.includes('spikes') || set.moves.includes('ceaselessedge')) {
				teamDetails.spikes = (teamDetails.spikes || 0) + 1;
			}
			if (set.moves.includes('toxicspikes') || set.ability === 'Toxic Debris') teamDetails.toxicSpikes = 1;
			if (set.moves.includes('stealthrock') || set.moves.includes('stoneaxe')) teamDetails.stealthRock = 1;
			if (set.moves.includes('stickyweb')) teamDetails.stickyWeb = 1;
			if (set.moves.includes('defog')) teamDetails.defog = 1;
			if (set.moves.includes('rapidspin') || set.moves.includes('mortalspin')) teamDetails.rapidSpin = 1;
			if (set.moves.includes('auroraveil')) teamDetails.screens = 1;
		}
		if (pokemon.length < this.maxTeamSize && pokemon.length < 12 && !isMonotype) { // large teams sometimes cannot be built
			throw new Error(`Could not build a random team for ${this.format} (seed=${seed})`);
		}

		return pokemon;
	}
}

export default RandomChampionsTeams;
